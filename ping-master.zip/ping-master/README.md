# ping the video calling application amongst users and groups
